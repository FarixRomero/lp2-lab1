﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LP2Clinica
{
    public partial class frmBuscarDemanda : Form
    {
        public frmBuscarDemanda()
        {
            InitializeComponent();
        }

        private void frmVisualizarDemanda_Load(object sender, EventArgs e)
        {

        }
    }
}
