﻿namespace LP2Clinica
{
    partial class frmModificarContraseña
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pContraseña = new System.Windows.Forms.Panel();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtContraseñaConfirmada = new System.Windows.Forms.TextBox();
            this.lblContraseñaConfirmada = new System.Windows.Forms.Label();
            this.txtContraseñaNueva = new System.Windows.Forms.TextBox();
            this.lblContraseñaNueva = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnConfirmar = new System.Windows.Forms.Button();
            this.pbCandado = new System.Windows.Forms.PictureBox();
            this.pContraseña.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCandado)).BeginInit();
            this.SuspendLayout();
            // 
            // pContraseña
            // 
            this.pContraseña.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(62)))), ((int)(((byte)(114)))));
            this.pContraseña.Controls.Add(this.txtEmail);
            this.pContraseña.Controls.Add(this.lblEmail);
            this.pContraseña.Controls.Add(this.txtContraseñaConfirmada);
            this.pContraseña.Controls.Add(this.lblContraseñaConfirmada);
            this.pContraseña.Controls.Add(this.txtContraseñaNueva);
            this.pContraseña.Controls.Add(this.lblContraseñaNueva);
            this.pContraseña.Location = new System.Drawing.Point(184, 210);
            this.pContraseña.Margin = new System.Windows.Forms.Padding(4);
            this.pContraseña.Name = "pContraseña";
            this.pContraseña.Size = new System.Drawing.Size(430, 380);
            this.pContraseña.TabIndex = 17;
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.Color.LightGray;
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmail.Location = new System.Drawing.Point(51, 117);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(335, 22);
            this.txtEmail.TabIndex = 30;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.ForeColor = System.Drawing.Color.White;
            this.lblEmail.Location = new System.Drawing.Point(46, 76);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(74, 28);
            this.lblEmail.TabIndex = 27;
            this.lblEmail.Text = "Email:";
            // 
            // txtContraseñaConfirmada
            // 
            this.txtContraseñaConfirmada.BackColor = System.Drawing.Color.LightGray;
            this.txtContraseñaConfirmada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtContraseñaConfirmada.Location = new System.Drawing.Point(51, 306);
            this.txtContraseñaConfirmada.Margin = new System.Windows.Forms.Padding(4);
            this.txtContraseñaConfirmada.Name = "txtContraseñaConfirmada";
            this.txtContraseñaConfirmada.Size = new System.Drawing.Size(334, 22);
            this.txtContraseñaConfirmada.TabIndex = 25;
            // 
            // lblContraseñaConfirmada
            // 
            this.lblContraseñaConfirmada.AutoSize = true;
            this.lblContraseñaConfirmada.BackColor = System.Drawing.Color.Transparent;
            this.lblContraseñaConfirmada.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContraseñaConfirmada.ForeColor = System.Drawing.Color.White;
            this.lblContraseñaConfirmada.Location = new System.Drawing.Point(46, 259);
            this.lblContraseñaConfirmada.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblContraseñaConfirmada.Name = "lblContraseñaConfirmada";
            this.lblContraseñaConfirmada.Size = new System.Drawing.Size(307, 28);
            this.lblContraseñaConfirmada.TabIndex = 23;
            this.lblContraseñaConfirmada.Text = "Confirmar nueva contraseña:";
            // 
            // txtContraseñaNueva
            // 
            this.txtContraseñaNueva.BackColor = System.Drawing.Color.LightGray;
            this.txtContraseñaNueva.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtContraseñaNueva.Location = new System.Drawing.Point(51, 215);
            this.txtContraseñaNueva.Margin = new System.Windows.Forms.Padding(4);
            this.txtContraseñaNueva.Name = "txtContraseñaNueva";
            this.txtContraseñaNueva.Size = new System.Drawing.Size(335, 22);
            this.txtContraseñaNueva.TabIndex = 22;
            // 
            // lblContraseñaNueva
            // 
            this.lblContraseñaNueva.AutoSize = true;
            this.lblContraseñaNueva.BackColor = System.Drawing.Color.Transparent;
            this.lblContraseñaNueva.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContraseñaNueva.ForeColor = System.Drawing.Color.White;
            this.lblContraseñaNueva.Location = new System.Drawing.Point(46, 159);
            this.lblContraseñaNueva.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblContraseñaNueva.Name = "lblContraseñaNueva";
            this.lblContraseñaNueva.Size = new System.Drawing.Size(207, 28);
            this.lblContraseñaNueva.TabIndex = 21;
            this.lblContraseñaNueva.Text = "Contraseña Nueva:";
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnCancelar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.ForeColor = System.Drawing.Color.White;
            this.btnCancelar.Location = new System.Drawing.Point(184, 613);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(211, 41);
            this.btnCancelar.TabIndex = 26;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnConfirmar
            // 
            this.btnConfirmar.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnConfirmar.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnConfirmar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirmar.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmar.ForeColor = System.Drawing.Color.White;
            this.btnConfirmar.Location = new System.Drawing.Point(403, 613);
            this.btnConfirmar.Margin = new System.Windows.Forms.Padding(4);
            this.btnConfirmar.Name = "btnConfirmar";
            this.btnConfirmar.Size = new System.Drawing.Size(211, 41);
            this.btnConfirmar.TabIndex = 27;
            this.btnConfirmar.Text = "Confirmar";
            this.btnConfirmar.UseVisualStyleBackColor = false;
            this.btnConfirmar.Click += new System.EventHandler(this.btnConfirmar_Click);
            // 
            // pbCandado
            // 
            this.pbCandado.BackColor = System.Drawing.Color.Transparent;
            this.pbCandado.Image = global::LP2Clinica.Properties.Resources.candado_removebg_preview;
            this.pbCandado.Location = new System.Drawing.Point(334, 133);
            this.pbCandado.Margin = new System.Windows.Forms.Padding(4);
            this.pbCandado.Name = "pbCandado";
            this.pbCandado.Size = new System.Drawing.Size(124, 118);
            this.pbCandado.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCandado.TabIndex = 31;
            this.pbCandado.TabStop = false;
            // 
            // frmModificarContraseña
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::LP2Clinica.Properties.Resources.PANTALLA_3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(821, 714);
            this.Controls.Add(this.pbCandado);
            this.Controls.Add(this.btnConfirmar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.pContraseña);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmModificarContraseña";
            this.Text = "Modificar Contraseña";
            this.pContraseña.ResumeLayout(false);
            this.pContraseña.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCandado)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pContraseña;
        private System.Windows.Forms.TextBox txtContraseñaConfirmada;
        private System.Windows.Forms.Label lblContraseñaConfirmada;
        private System.Windows.Forms.TextBox txtContraseñaNueva;
        private System.Windows.Forms.Label lblContraseñaNueva;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnConfirmar;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.PictureBox pbCandado;
    }
}