﻿namespace LP2Clinica
{
    partial class frmMostrarPerfil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnModificarContra = new System.Windows.Forms.Button();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pModificar = new System.Windows.Forms.Panel();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblDNI = new System.Windows.Forms.Label();
            this.lblNombreCompleto = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dni = new System.Windows.Forms.Label();
            this.nombrecompleto = new System.Windows.Forms.Label();
            this.btnModificarDatos = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pModificar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnModificarContra
            // 
            this.btnModificarContra.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnModificarContra.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnModificarContra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificarContra.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarContra.ForeColor = System.Drawing.Color.White;
            this.btnModificarContra.Location = new System.Drawing.Point(283, 452);
            this.btnModificarContra.Name = "btnModificarContra";
            this.btnModificarContra.Size = new System.Drawing.Size(210, 33);
            this.btnModificarContra.TabIndex = 74;
            this.btnModificarContra.Text = "Modificar Contraseña";
            this.btnModificarContra.UseVisualStyleBackColor = false;
            this.btnModificarContra.Click += new System.EventHandler(this.btnModificarContra_Click);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(37)))), ((int)(((byte)(91)))));
            this.lblTitulo.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Location = new System.Drawing.Point(280, 26);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(226, 41);
            this.lblTitulo.TabIndex = 76;
            this.lblTitulo.Text = "Modificar datos";
            // 
            // pModificar
            // 
            this.pModificar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(62)))), ((int)(((byte)(114)))));
            this.pModificar.Controls.Add(this.lblUserName);
            this.pModificar.Controls.Add(this.lblEmail);
            this.pModificar.Controls.Add(this.lblDNI);
            this.pModificar.Controls.Add(this.lblNombreCompleto);
            this.pModificar.Controls.Add(this.label1);
            this.pModificar.Controls.Add(this.label2);
            this.pModificar.Controls.Add(this.dni);
            this.pModificar.Controls.Add(this.nombrecompleto);
            this.pModificar.Location = new System.Drawing.Point(212, 71);
            this.pModificar.Name = "pModificar";
            this.pModificar.Size = new System.Drawing.Size(352, 296);
            this.pModificar.TabIndex = 73;
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.BackColor = System.Drawing.Color.Transparent;
            this.lblUserName.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(255)))), ((int)(((byte)(240)))));
            this.lblUserName.Location = new System.Drawing.Point(67, 239);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(117, 22);
            this.lblUserName.TabIndex = 35;
            this.lblUserName.Text = "_User Name_";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.BackColor = System.Drawing.Color.Transparent;
            this.lblEmail.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(255)))), ((int)(((byte)(240)))));
            this.lblEmail.Location = new System.Drawing.Point(67, 182);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(80, 22);
            this.lblEmail.TabIndex = 34;
            this.lblEmail.Text = "_EMAIL_";
            // 
            // lblDNI
            // 
            this.lblDNI.AutoSize = true;
            this.lblDNI.BackColor = System.Drawing.Color.Transparent;
            this.lblDNI.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDNI.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(255)))), ((int)(((byte)(240)))));
            this.lblDNI.Location = new System.Drawing.Point(67, 119);
            this.lblDNI.Name = "lblDNI";
            this.lblDNI.Size = new System.Drawing.Size(60, 22);
            this.lblDNI.TabIndex = 33;
            this.lblDNI.Text = "_DNI_";
            // 
            // lblNombreCompleto
            // 
            this.lblNombreCompleto.AutoSize = true;
            this.lblNombreCompleto.BackColor = System.Drawing.Color.Transparent;
            this.lblNombreCompleto.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreCompleto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(255)))), ((int)(((byte)(240)))));
            this.lblNombreCompleto.Location = new System.Drawing.Point(67, 52);
            this.lblNombreCompleto.Name = "lblNombreCompleto";
            this.lblNombreCompleto.Size = new System.Drawing.Size(173, 22);
            this.lblNombreCompleto.TabIndex = 32;
            this.lblNombreCompleto.Text = "_Nombre Completo_";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(48, 216);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 22);
            this.label1.TabIndex = 31;
            this.label1.Text = "Username:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(48, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 22);
            this.label2.TabIndex = 29;
            this.label2.Text = "Email:";
            // 
            // dni
            // 
            this.dni.AutoSize = true;
            this.dni.BackColor = System.Drawing.Color.Transparent;
            this.dni.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dni.ForeColor = System.Drawing.Color.White;
            this.dni.Location = new System.Drawing.Point(48, 88);
            this.dni.Name = "dni";
            this.dni.Size = new System.Drawing.Size(45, 22);
            this.dni.TabIndex = 23;
            this.dni.Text = "DNI:";
            // 
            // nombrecompleto
            // 
            this.nombrecompleto.AutoSize = true;
            this.nombrecompleto.BackColor = System.Drawing.Color.Transparent;
            this.nombrecompleto.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombrecompleto.ForeColor = System.Drawing.Color.White;
            this.nombrecompleto.Location = new System.Drawing.Point(48, 28);
            this.nombrecompleto.Name = "nombrecompleto";
            this.nombrecompleto.Size = new System.Drawing.Size(158, 22);
            this.nombrecompleto.TabIndex = 21;
            this.nombrecompleto.Text = "Nombre Completo:";
            // 
            // btnModificarDatos
            // 
            this.btnModificarDatos.BackColor = System.Drawing.Color.LightSeaGreen;
            this.btnModificarDatos.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnModificarDatos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificarDatos.Font = new System.Drawing.Font("Tw Cen MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificarDatos.ForeColor = System.Drawing.Color.White;
            this.btnModificarDatos.Location = new System.Drawing.Point(283, 400);
            this.btnModificarDatos.Name = "btnModificarDatos";
            this.btnModificarDatos.Size = new System.Drawing.Size(210, 33);
            this.btnModificarDatos.TabIndex = 77;
            this.btnModificarDatos.Text = "Modificar Datos";
            this.btnModificarDatos.UseVisualStyleBackColor = false;
            this.btnModificarDatos.Click += new System.EventHandler(this.btnModificarDatos_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::LP2Clinica.Properties.Resources.profilepicture;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Image = global::LP2Clinica.Properties.Resources.Madurez_emocional_7;
            this.pictureBox1.Location = new System.Drawing.Point(31, 71);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 141);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // frmMostrarPerfil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(37)))), ((int)(((byte)(91)))));
            this.ClientSize = new System.Drawing.Size(611, 531);
            this.Controls.Add(this.btnModificarDatos);
            this.Controls.Add(this.btnModificarContra);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.pModificar);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmMostrarPerfil";
            this.ShowInTaskbar = false;
            this.Text = "V";
            this.pModificar.ResumeLayout(false);
            this.pModificar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnModificarContra;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pModificar;
        private System.Windows.Forms.Label dni;
        private System.Windows.Forms.Label nombrecompleto;
        private System.Windows.Forms.Label lblNombreCompleto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnModificarDatos;
        private System.Windows.Forms.Label lblDNI;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblUserName;
    }
}